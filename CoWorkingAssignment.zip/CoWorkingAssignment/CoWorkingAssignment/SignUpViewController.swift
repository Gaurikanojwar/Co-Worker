//
//  SignUpViewController.swift
//  CoWorkingAssignment
//
//  Created by GAURI ATUL KANOJWAR on 01/12/23.
//

import UIKit

class SignUpViewController: UIViewController {

    
    @IBOutlet weak var fullNameTxt: UITextField!
    @IBOutlet weak var mobNumTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var SignInBtnOutlet: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.SignInBtnOutlet.layer.cornerRadius = 10
    }

    @IBAction func SignUpBtn(_ sender: Any) {
        let hVc = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        self.navigationController?.pushViewController(hVc, animated: true)
    }
    
    @IBAction func logInBtn(_ sender: Any) {
        let hVc = self.storyboard?.instantiateViewController(withIdentifier: "LogInViewController") as! LogInViewController
        self.navigationController?.pushViewController(hVc, animated: true)
    }
    
    
}
