//
//  LogInViewController.swift
//  CoWorkingAssignment
//
//  Created by GAURI ATUL KANOJWAR on 01/12/23.
//

import UIKit

class LogInViewController: UIViewController {
    
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var passTxt: UITextField!
    @IBOutlet weak var logInBtnOutlet: UIButton!
    
    var iconclick = false
    let imageicone = UIImageView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.logInBtnOutlet.layer.cornerRadius = 10
        imageicone.image = UIImage(named: "mdi_eye-off-outline")
        let contentView = UIView()
        contentView.addSubview(imageicone)
        
        contentView.frame = CGRect(x: 0, y: 0, width: UIImage(named: "mdi_eye-off-outline")!.size.width, height: UIImage(named: "mdi_eye-off-outline")!.size.height)
        
        imageicone.frame = CGRect(x: -10, y: 0, width: UIImage(named: "mdi_eye-off-outline")!.size.width, height: UIImage(named: "mdi_eye-off-outline")!.size.height)
        passTxt.rightView = contentView
        passTxt.rightViewMode = .always
        
        let tapGestureRec = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRec:)))
        imageicone.isUserInteractionEnabled = true
        imageicone.addGestureRecognizer(tapGestureRec)
        
    }
    
    @objc func imageTapped(tapGestureRec:UITapGestureRecognizer)
    {
        let tappedImage = tapGestureRec.view as! UIImageView
        
        if iconclick{
            iconclick = false
            tappedImage.image = UIImage(named: "visible")
            passTxt.isSecureTextEntry = false
        }else{
            iconclick = true
            tappedImage.image = UIImage(named: "mdi_eye-off-outline")
            passTxt.isSecureTextEntry = true
        }
    }
    
    @IBAction func logInBtn(_ sender: Any) {
        let hVc = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        self.navigationController?.pushViewController(hVc, animated: true)
        
    }
    
    @IBAction func createAccountBtn(_ sender: Any) {
        
        let lVc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
        self.navigationController?.pushViewController(lVc, animated: true)
    }
    
    
}
