//
//  DeskViewController.swift
//  CoWorkingAssignment
//
//  Created by GAURI ATUL KANOJWAR on 01/12/23.
//

import UIKit
import CalendarKit

class DeskViewController: DayViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

}
