//
//  HomeViewController.swift
//  CoWorkingAssignment
//
//  Created by GAURI ATUL KANOJWAR on 01/12/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func bookWorkerBtn(_ sender: Any) {
        let hVc = self.storyboard?.instantiateViewController(withIdentifier: "DeskViewController") as! DeskViewController
        self.navigationController?.pushViewController(hVc, animated: true)
    }
    
    @IBAction func bookMeetingBtn(_ sender: Any) {
        let hVc = self.storyboard?.instantiateViewController(withIdentifier: "DeskViewController") as! DeskViewController
        self.navigationController?.pushViewController(hVc, animated: true)
    }
    
    @IBAction func bookHistoryBtn(_ sender: Any) {
        let hVc = self.storyboard?.instantiateViewController(withIdentifier: "BookingViewController") as! BookingViewController
        self.navigationController?.pushViewController(hVc, animated: true)
    }
    
    
    
    
}
